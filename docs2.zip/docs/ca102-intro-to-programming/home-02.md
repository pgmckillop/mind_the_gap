# Content Area 2: Introduction to Programming

## List of New Content and Major Changes
